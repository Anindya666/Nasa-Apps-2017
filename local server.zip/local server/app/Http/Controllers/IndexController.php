<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class IndexController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    //
    public function getRatio (Request $request) {

        $inLon = $request->input('lon');
        $inLat = $request->input('lat');

        $results = DB::select("SELECT longitude, lattitude FROM quakes");

        $minDistanceInKM = 9999;
        $minLat = 0;
        $minLon = 0;
        foreach ($results as $row) {
            $lon = $row->longitude;
            $lat = $row->lattitude;

            $dist = $this->getDistanceInKM($inLon, $inLat, $lon, $lat);
            // echo $dist.'<br>';
            if ($dist < $minDistanceInKM) {
                $minDistanceInKM = $dist;
                $minLon = $lon;
                $minLat = $lat;
            }
        }

        echo json_encode(array('minLat' => $minLat, 'minLon' => $minLon, 'dist' => $minDistanceInKM ));
        
    }

    private function getDistanceInKM ($lon1, $lat1, $lon2, $lat2) {
        $R = 6371;
        $dLat = deg2rad($lat2-$lat1); 
        $dLon = deg2rad($lon2-$lon1); 

        $a = sin($dLat/2) * sin($dLat/2) + 
             cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * 
             sin($dLon/2) * sin($dLon/2); 


        $c = 2 * atan2(sqrt($a), sqrt(1-$a)); 
        $d = $R * $c; // Distance in km
        
        return $d;
    }

    private function deg2rad($deg) {
        return $deg*3.14159/180;
    }
}
