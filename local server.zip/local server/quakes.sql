-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 23, 2017 at 02:48 PM
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `nasaac`
--

-- --------------------------------------------------------

--
-- Table structure for table `quakes`
--

CREATE TABLE IF NOT EXISTS `quakes` (
`id` int(11) NOT NULL,
  `longitude` double NOT NULL,
  `lattitude` double NOT NULL,
  `depth` float NOT NULL,
  `magnitude` float NOT NULL,
  `mag_type` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `gap` int(11) NOT NULL,
  `dmin` float NOT NULL,
  `rps` float NOT NULL,
  `place` text COLLATE utf8_unicode_ci NOT NULL,
  `horizontal` float NOT NULL,
  `depth_error` float NOT NULL,
  `mag_error` float NOT NULL,
  `mag_nst` int(11) NOT NULL,
  `time` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `quakes`
--

INSERT INTO `quakes` (`id`, `longitude`, `lattitude`, `depth`, `magnitude`, `mag_type`, `gap`, `dmin`, `rps`, `place`, `horizontal`, `depth_error`, `mag_error`, `mag_nst`, `time`, `updated_at`) VALUES
(1, 88.6261, 27.2442, 10, 4.5, 'mb', 113, 2.981, 0.8, '9km S of Gangtok, India', 8, 1.9, 0.07, 60, '2017-03-26 03:21:10', '2017-03-27 03:17:50'),
(2, 95.0201, 25.0469, 104, 4.5, 'mb', 110, 1.044, 0.91, '86km SE of Phek, India', 5.9, 5.4, 0.088, 38, '2017-03-25 03:02:56', '2017-04-08 04:00:22'),
(3, 92.5637, 25.382, 38.66, 4.4, 'mb', 98, 0.665, 1.51, '52km WNW of Haflong, India', 7.2, 8.4, 0.19, 8, '2017-03-21 03:15:46', '2017-04-05 04:15:36'),
(4, 94.5703, 24.7062, 69.71, 4.7, 'mb', 101, 0.534, 0.72, '51km E of Yairipok, India', 7.5, 3.6, 0.142, 15, '2017-03-09 03:02:11', '2017-04-11 04:01:31'),
(5, 89.1143, 26.9162, 10, 4, 'mb', 138, 2.805, 1.03, '2km NE of Samtse, Bhutan', 6.2, 1.9, 0.133, 15, '2017-03-07 03:10:57', '2017-04-10 04:13:22'),
(6, 95.1428, 25.1149, 89.95, 4.3, 'mb', 109, 1.168, 0.67, '88km SE of Phek, India', 7.5, 10.2, 0.113, 22, '2017-03-06 03:21:07', '2017-03-21 03:04:39'),
(7, 94.6658, 25.1865, 74.07, 5.1, 'mb', 27, 1.009, 0.95, '55km SSE of Phek, India', 6.5, 5.1, 0.042, 181, '2017-03-04 03:02:54', '2017-03-23 03:23:17'),
(8, 94.5486, 24.8454, 65.83, 4.1, 'mb', 66, 0.653, 0.57, '52km ENE of Yairipok, India', 7.4, 7.6, 0.127, 17, '2017-03-03 03:23:03', '2017-03-07 03:01:09'),
(9, 85.9319, 27.3706, 20.28, 4.6, 'mb', 156, 0.626, 0.69, '16km WNW of Ramechhap, Nepal', 7.5, 3.7, 0.066, 69, '2017-02-27 02:04:42', '2017-04-04 04:02:53'),
(10, 86.0789, 27.4259, 11.23, 4.7, 'mb', 57, 0.725, 0.62, '11km N of Ramechhap, Nepal', 6, 3.8, 0.059, 86, '2017-02-27 02:03:46', '2017-04-09 04:21:13'),
(11, 93.4825, 24.0437, 59.8, 5, 'mb', 43, 0.769, 0.81, '37km SSW of Churachandpur, India', 5.1, 5, 0.048, 137, '2017-02-24 02:12:51', '2017-03-30 03:11:27'),
(12, 91.1035, 25.548, 36.94, 4.4, 'mb', 66, 0.68, 0.66, '16km WNW of Nongstoin, India', 4.6, 8, 0.102, 28, '2017-02-12 02:04:34', '2017-02-26 02:04:45'),
(13, 94.7713, 22.5372, 121, 4.5, 'mb', 63, 1.088, 0.99, '59km NW of Monywa, Burma', 6.5, 6.6, 0.085, 40, '2017-02-08 02:20:17', '2017-02-27 02:18:15'),
(14, 91.8799, 25.6419, 35, 4.3, 'mb', 115, 0.077, 1.08, '8km N of Shillong, India', 14.2, 2, 0.177, 9, '2017-01-24 01:12:39', '2017-04-19 04:18:58'),
(15, 94.7635, 19.8125, 71.98, 4.3, 'mb', 48, 2.529, 0.78, '40km SSW of Magway, Burma', 6.7, 3.6, 0.088, 37, '2017-01-21 01:21:19', '2017-04-12 04:02:04'),
(16, 92.6836, 28.1784, 40.21, 4.1, 'mb', 104, 2.041, 0.8, '82km ENE of Xoixar, China', 5.8, 9.7, 0.127, 17, '2017-01-19 01:19:37', '2017-04-12 04:02:01'),
(17, 94.5655, 24.559, 63, 4.5, 'mb', 58, 0.407, 0.92, '51km ESE of Yairipok, India', 7.7, 6, 0.113, 23, '2017-01-18 01:03:22', '2017-04-12 04:02:00'),
(18, 95.364, 26.4049, 68.8, 4.5, 'mb', 84, 2.37, 1.01, '46km SE of Mon, India', 7.4, 7.3, 0.093, 34, '2017-01-12 01:09:08', '2017-04-01 04:00:10'),
(19, 94.7422, 22.9682, 123.35, 4.6, 'mb', 69, 1.103, 0.68, '80km SSE of Mawlaik, Burma', 6.5, 6.8, 0.103, 28, '2017-01-04 01:14:08', '2017-03-27 03:23:22'),
(20, 93.8486, 27.9089, 18.03, 4.4, 'mb', 76, 2.935, 0.79, '30km N of Ziro, India', 8, 4, 0.075, 51, '2017-01-03 01:19:27', '2017-03-27 03:23:20');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `quakes`
--
ALTER TABLE `quakes`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `quakes`
--
ALTER TABLE `quakes`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=21;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
